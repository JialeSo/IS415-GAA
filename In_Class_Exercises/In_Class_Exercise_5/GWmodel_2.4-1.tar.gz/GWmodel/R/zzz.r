.onAttach <- function(lib, pkg) {
	packageStartupMessage("Welcome to GWmodel version 2.4-2.\n", appendLF = FALSE)
}