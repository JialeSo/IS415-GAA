# bold_p() messaging

    Code
      bold_p(tbl_summary(trial, by = trt, include = c(response, marker, trt),
      missing = "no"))
    Condition
      Error in `bold_p()`:
      ! There is no column named "p.value" in `x$table_body`.

