# initializing new env where all gtsummary theme elements are saved
env_gtsummary_theme <- rlang::new_environment()
