Hi Prof,

These are my files for Take Home Exercise 2.

Directory path to the HTML file:
site -> take_home_exercises -> take_home_exercise_2 -> Take_Home_Exercise2.html

alternatively, you may view it on netlify

https://is415-jiale-ay2024-2025t1.netlify.app/take_home_exercises/take_home_exercise_2/take_home_exercise2

Thank you for your understanding.

Best regards,
Jiale So.
